name='cigar_coordinates'

from .cigar_coordinates import CigarCoordinates